import React, { useState, useEffect } from "react";
import SplashScreen from "./SplashScreen";
import Robot, { RobotState } from "./Robot";
import ErrorNotification from "./ErrorNotification";
import ResultNotification from "./ResultNotification";
import LogicCalculation, { CalculatorStep } from "./LogicCalculation";

export default function ChatCalculator() {
  const [appStarted, setAppStarted] = useState(false);
  const [robotState, setRobotState] = useState<RobotState>('idle');
  const [robotStatus, setRobotStatus] = useState<string>('READY');
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  
  // Shared state needed for Robot component
  const [currentStep, setCurrentStep] = useState<CalculatorStep>('category');
  const [unitRate, setUnitRate] = useState<number>(0);
  const [baseUnit, setBaseUnit] = useState<string>('kg');

  // Custom Notification State
  const [showNotification, setShowNotification] = useState(false);
  const [notificationMessage, setNotificationMessage] = useState('');

  // Result Notification State
  const [showResult, setShowResult] = useState(false);
  const [resultMessage, setResultMessage] = useState('');

  // Monitor online/offline status
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const triggerHaptic = async (intensity: 'light' | 'medium' | 'heavy' = 'light') => {
    try {
      if ('vibrate' in navigator) {
        const duration = intensity === 'light' ? 50 : intensity === 'medium' ? 100 : 200;
        navigator.vibrate(duration);
      }
    } catch (error) {
      // Haptics not supported
    }
  };

  const showCustomNotification = (message: string) => {
    setNotificationMessage(message);
    setShowNotification(true);
    playRetroSound('error');
    triggerHaptic('medium');
  };

  const showResultNotification = (message: string) => {
    setResultMessage(message);
    setShowResult(true);
    // Sound is handled in LogicCalculation usually, but ensures sync if called elsewhere
  };

  const playRetroSound = (type: 'beep' | 'confirm' | 'calculate' | 'success' | 'select' | 'error' | 'swoosh' | 'digital' | 'laser' | 'coin' | 'power' | 'reset') => {
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      
      switch(type) {
        case 'beep':
          const beepOsc = audioContext.createOscillator();
          const beepGain = audioContext.createGain();
          beepOsc.connect(beepGain);
          beepGain.connect(audioContext.destination);
          beepOsc.frequency.setValueAtTime(880, audioContext.currentTime);
          beepGain.gain.setValueAtTime(0.2, audioContext.currentTime);
          beepGain.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);
          beepOsc.start();
          beepOsc.stop(audioContext.currentTime + 0.1);
          break;
        case 'confirm':
          [440, 554, 659, 880].forEach((freq, i) => {
            const osc = audioContext.createOscillator();
            const gain = audioContext.createGain();
            osc.connect(gain);
            gain.connect(audioContext.destination);
            osc.frequency.setValueAtTime(freq, audioContext.currentTime + i * 0.08);
            gain.gain.setValueAtTime(0.15, audioContext.currentTime + i * 0.08);
            gain.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.4);
            osc.start(audioContext.currentTime + i * 0.08);
            osc.stop(audioContext.currentTime + 0.4);
          });
          break;
        case 'calculate':
          const calcOsc = audioContext.createOscillator();
          const calcGain = audioContext.createGain();
          calcOsc.connect(calcGain);
          calcGain.connect(audioContext.destination);
          calcOsc.type = 'square';
          calcOsc.frequency.setValueAtTime(300, audioContext.currentTime);
          calcOsc.frequency.exponentialRampToValueAtTime(1000, audioContext.currentTime + 0.3);
          calcGain.gain.setValueAtTime(0.1, audioContext.currentTime);
          calcGain.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
          calcOsc.start();
          calcOsc.stop(audioContext.currentTime + 0.3);
          break;
        case 'success':
          [523, 659, 784, 1047].forEach((freq, i) => {
            const osc = audioContext.createOscillator();
            const gain = audioContext.createGain();
            osc.connect(gain);
            gain.connect(audioContext.destination);
            osc.type = 'triangle';
            osc.frequency.setValueAtTime(freq, audioContext.currentTime + i * 0.12);
            gain.gain.setValueAtTime(0.2, audioContext.currentTime + i * 0.12);
            gain.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.6);
            osc.start(audioContext.currentTime + i * 0.12);
            osc.stop(audioContext.currentTime + 0.6);
          });
          break;
        case 'select':
          const selectOsc = audioContext.createOscillator();
          const selectGain = audioContext.createGain();
          selectOsc.connect(selectGain);
          selectGain.connect(audioContext.destination);
          selectOsc.type = 'sine';
          selectOsc.frequency.setValueAtTime(1200, audioContext.currentTime);
          selectGain.gain.setValueAtTime(0.15, audioContext.currentTime);
          selectGain.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.06);
          selectOsc.start();
          selectOsc.stop(audioContext.currentTime + 0.06);
          break;
        case 'error':
          const errorOsc = audioContext.createOscillator();
          const errorGain = audioContext.createGain();
          errorOsc.connect(errorGain);
          errorGain.connect(audioContext.destination);
          errorOsc.type = 'sawtooth';
          errorOsc.frequency.setValueAtTime(200, audioContext.currentTime);
          errorGain.gain.setValueAtTime(0.2, audioContext.currentTime);
          errorGain.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.15);
          errorOsc.start();
          errorOsc.stop(audioContext.currentTime + 0.15);
          break;
        case 'swoosh':
          const swooshOsc = audioContext.createOscillator();
          const swooshGain = audioContext.createGain();
          swooshOsc.connect(swooshGain);
          swooshGain.connect(audioContext.destination);
          swooshOsc.type = 'triangle';
          swooshOsc.frequency.setValueAtTime(1500, audioContext.currentTime);
          swooshOsc.frequency.exponentialRampToValueAtTime(300, audioContext.currentTime + 0.2);
          swooshGain.gain.setValueAtTime(0.1, audioContext.currentTime);
          swooshGain.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.2);
          swooshOsc.start();
          swooshOsc.stop(audioContext.currentTime + 0.2);
          break;
        case 'digital':
          const digitalOsc = audioContext.createOscillator();
          const digitalGain = audioContext.createGain();
          digitalOsc.connect(digitalGain);
          digitalGain.connect(audioContext.destination);
          digitalOsc.type = 'square';
          digitalOsc.frequency.setValueAtTime(800, audioContext.currentTime);
          digitalOsc.frequency.setValueAtTime(400, audioContext.currentTime + 0.05);
          digitalOsc.frequency.setValueAtTime(800, audioContext.currentTime + 0.1);
          digitalGain.gain.setValueAtTime(0.12, audioContext.currentTime);
          digitalGain.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.15);
          digitalOsc.start();
          digitalOsc.stop(audioContext.currentTime + 0.15);
          break;
        case 'laser':
          const laserOsc = audioContext.createOscillator();
          const laserGain = audioContext.createGain();
          laserOsc.connect(laserGain);
          laserGain.connect(audioContext.destination);
          laserOsc.type = 'sawtooth';
          laserOsc.frequency.setValueAtTime(2000, audioContext.currentTime);
          laserOsc.frequency.exponentialRampToValueAtTime(100, audioContext.currentTime + 0.3);
          laserGain.gain.setValueAtTime(0.15, audioContext.currentTime);
          laserGain.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
          laserOsc.start();
          laserOsc.stop(audioContext.currentTime + 0.3);
          break;
        case 'coin':
          [880, 1108, 1397].forEach((freq, i) => {
            const osc = audioContext.createOscillator();
            const gain = audioContext.createGain();
            osc.connect(gain);
            gain.connect(audioContext.destination);
            osc.type = 'sine';
            osc.frequency.setValueAtTime(freq, audioContext.currentTime + i * 0.05);
            gain.gain.setValueAtTime(0.15, audioContext.currentTime + i * 0.05);
            gain.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.25);
            osc.start(audioContext.currentTime + i * 0.05);
            osc.stop(audioContext.currentTime + 0.25);
          });
          break;
        case 'power':
          const powerOsc = audioContext.createOscillator();
          const powerGain = audioContext.createGain();
          powerOsc.connect(powerGain);
          powerGain.connect(audioContext.destination);
          powerOsc.type = 'triangle';
          powerOsc.frequency.setValueAtTime(440, audioContext.currentTime);
          powerOsc.frequency.exponentialRampToValueAtTime(880, audioContext.currentTime + 0.4);
          powerGain.gain.setValueAtTime(0.1, audioContext.currentTime);
          powerGain.gain.setValueAtTime(0.2, audioContext.currentTime + 0.2);
          powerGain.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.4);
          powerOsc.start();
          powerOsc.stop(audioContext.currentTime + 0.4);
          break;
        case 'reset':
          const resetOsc = audioContext.createOscillator();
          const resetGain = audioContext.createGain();
          resetOsc.connect(resetGain);
          resetGain.connect(audioContext.destination);
          resetOsc.type = 'square';
          resetOsc.frequency.setValueAtTime(1000, audioContext.currentTime);
          resetOsc.frequency.linearRampToValueAtTime(200, audioContext.currentTime + 0.25);
          resetGain.gain.setValueAtTime(0.15, audioContext.currentTime);
          resetGain.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.25);
          resetOsc.start();
          resetOsc.stop(audioContext.currentTime + 0.25);
          break;
      }
    } catch (error) {
      console.log('Audio not supported');
    }
  };

  const triggerRobotAnimation = (animation: RobotState) => {
    setRobotState('idle');
    setTimeout(() => {
      setRobotState(animation);
      let duration = 3000;
      if (animation === 'confirm-rate') duration = 1600;
      else if (animation === 'excited') duration = 4500;
      else if (animation === 'glitching') duration = 800;
      else if (animation === 'nodding') duration = 1500;
      else if (animation === 'teleporting') duration = 1200;
      else if (animation === 'processing') duration = 2000;
      else if (animation === 'thinking') duration = 2500;
      else if (animation === 'scanning') duration = 2000;
      else if (animation === 'amazed') duration = 2000;
      else if (animation === 'dancing') duration = 4200;
      else if (animation === 'celebrating') duration = 1000;
      
      setTimeout(() => {
        setRobotState('idle');
      }, duration);
    }, 50);
  };

  const updateSystemMessage = (html: string) => {
      const readout = document.querySelector('.header-chat');
      if (readout) readout.innerHTML = html;
  };

  // Sync handler to update Robot prop state when LogicCalculation changes
  const handleSyncState = ({ currentStep, unitRate, baseUnit }: { currentStep: CalculatorStep, unitRate: number, baseUnit: string }) => {
    setCurrentStep(currentStep);
    setUnitRate(unitRate);
    setBaseUnit(baseUnit);
  };

  const handleAppStart = () => {
    playRetroSound('power');
    setAppStarted(true);
  };

  if (!appStarted) {
    return <SplashScreen onStart={handleAppStart} />;
  }

  return (
    <div className="min-h-screen h-screen flex flex-col bg-bg-dark text-white relative overflow-hidden chat-calculator">
      
      {/* Error Dialog Modal */}
      {showNotification && (
        <ErrorNotification 
          message={notificationMessage} 
          onClose={() => setShowNotification(false)} 
        />
      )}

      {/* Result Dialog Modal */}
      {showResult && (
        <ResultNotification 
          message={resultMessage} 
          onClose={() => setShowResult(false)} 
        />
      )}
      
      {/* Fixed Border Lines - Always visible now */}
      <div className="absolute top-44 left-0 w-full h-0.5 bg-primary z-30"></div>
      <div className="absolute top-44 left-1/2 bottom-0 w-0.5 bg-primary z-30"></div>
      
      {/* Chat Assistant Header - Fixed height */}
      <div className="h-44 bg-gradient-to-r from-bg-dark via-bg-card to-bg-dark p-4 relative flex-shrink-0 z-20">
        <div className="absolute inset-0 opacity-10" style={{
          backgroundImage: `
            linear-gradient(rgba(239, 239, 187, 0.3) 1px, transparent 1px),
            linear-gradient(90deg, rgba(239, 239, 187, 0.3) 1px, transparent 1px)
          `,
          backgroundSize: '25px 25px'
        }}></div>
        <div className="flex items-start space-x-3 h-full">
          <div className="w-16 h-16 bg-gradient-to-b from-primary to-dark-blue rounded-xl border-2 border-accent flex items-center justify-center flex-shrink-0 shadow-lg relative">
            <div className="absolute -top-2 left-1/2 transform -translate-x-1/2 w-1.5 h-4 bg-gray-500 border border-dark-blue"></div>
            <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 w-3 h-3 bg-red-500 rounded-full border border-red-700 animate-pulse"></div>
            <div className="flex space-x-2 bg-black/40 p-1.5 rounded-md border border-gray-600">
              <div className="w-2.5 h-2.5 bg-accent rounded-full shadow-[0_0_5px_#EFEFBB]"></div>
              <div className="w-2.5 h-2.5 bg-accent rounded-full shadow-[0_0_5px_#EFEFBB]"></div>
            </div>
            <div className="absolute -left-2 w-1.5 h-6 bg-gray-500 rounded-l border border-dark-blue"></div>
            <div className="absolute -right-2 w-1.5 h-6 bg-gray-500 rounded-r border border-dark-blue"></div>
          </div>
          
          <div className="flex-1 h-full flex flex-col min-h-0">
            <div className="text-accent text-xs sm:text-sm font-bold mb-2 tracking-wider flex items-center">
              <i className="fas fa-robot mr-2"></i>
              RETRO-BOT ASSISTANT
            </div>
            <div className="text-white text-sm sm:text-base font-semibold mb-1 tracking-wide break-words">
              Welcome to Quantity Price Calculator
            </div>
            <div className="flex-1 min-h-0">
              <div className="chat-bubble-retro w-full flex items-start h-full">
                <div className="header-chat text-white text-xs font-medium leading-tight w-full overflow-hidden">
                  <div>
                    🤖 Welcome to Quantity Price Calculator!<br />
                    <span className="text-accent font-bold">Select your unit category to begin calculations</span><br />
                    <span className="text-xs opacity-80">I'll help you calculate prices and quantities!</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Main Content Area - Default Flex (Row) */}
      <div className={`flex-1 flex relative z-10 overflow-hidden transition-all duration-300`}>
        
        {/* Left Side - Robot */}
        <Robot 
          state={robotState}
          currentStep={currentStep}
          unitRate={unitRate}
          baseUnit={baseUnit}
        />
        
        {/* Right Side - Interface */}
        <LogicCalculation 
          playRetroSound={playRetroSound}
          triggerHaptic={triggerHaptic}
          showCustomNotification={showCustomNotification}
          showResultNotification={showResultNotification}
          triggerRobotAnimation={triggerRobotAnimation}
          updateSystemMessage={updateSystemMessage}
          setRobotStatus={setRobotStatus}
          onSyncState={handleSyncState}
        />
        
      </div>
    </div>
  );
}